const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const dataDir = path.join(__dirname, '..', 'data');
const dbPath = path.join(dataDir, 'shop.json');

fs.mkdirSync(dataDir, { recursive: true });

function now() {
  return new Date().toISOString();
}

function emptyState() {
  return {
    meta: {
      nextUserId: 1,
      nextProductId: 1,
      nextOrderId: 1,
      nextOrderItemId: 1
    },
    users: [],
    products: [],
    orders: [],
    orderItems: []
  };
}

function normalizeState(input) {
  const fallback = emptyState();
  const state = input && typeof input === 'object' ? input : fallback;
  state.meta = { ...fallback.meta, ...(state.meta || {}) };
  state.users = Array.isArray(state.users) ? state.users : [];
  state.products = Array.isArray(state.products) ? state.products : [];
  state.orders = Array.isArray(state.orders) ? state.orders : [];
  state.orderItems = Array.isArray(state.orderItems) ? state.orderItems : [];
  return state;
}

function loadState() {
  if (!fs.existsSync(dbPath)) return emptyState();
  try {
    return normalizeState(JSON.parse(fs.readFileSync(dbPath, 'utf8')));
  } catch (error) {
    throw new Error(`Không thể đọc database ${dbPath}: ${error.message}`);
  }
}

let state = loadState();

function saveState(nextState = state) {
  const tempPath = `${dbPath}.tmp`;
  fs.writeFileSync(tempPath, JSON.stringify(nextState, null, 2), 'utf8');
  if (fs.existsSync(dbPath)) fs.rmSync(dbPath, { force: true });
  fs.renameSync(tempPath, dbPath);
  state = nextState;
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return `scrypt$${salt}$${derived}`;
}

function verifyPassword(password, storedHash) {
  try {
    const [algorithm, salt, expectedHex] = String(storedHash).split('$');
    if (algorithm !== 'scrypt' || !salt || !expectedHex) return false;
    const actual = crypto.scryptSync(String(password), salt, 64);
    const expected = Buffer.from(expectedHex, 'hex');
    return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}

function clone(value) {
  return structuredClone(value);
}

function initializeDatabase() {
  seedAdmin();
  seedProducts();
  saveState();
}

function seedAdmin() {
  const username = process.env.ADMIN_USERNAME || 'admin';
  const password = process.env.ADMIN_PASSWORD || 'Admin@123';
  if (state.users.some((user) => user.username === username)) return;

  state.users.push({
    id: state.meta.nextUserId++,
    username,
    password_hash: hashPassword(password),
    role: 'admin',
    created_at: now()
  });
  console.log(`Tài khoản admin đã tạo: ${username}`);
}

function seedProducts() {
  if (state.products.length > 0) return;
  const items = [
    {
      name: 'Tai nghe Bluetooth Nova Pro',
      description: 'Âm thanh rõ, chống ồn chủ động, thời lượng pin lên đến 32 giờ.',
      price: 1290000,
      image_url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=1200&q=80',
      stock: 18,
      category: 'Âm thanh'
    },
    {
      name: 'Bàn phím cơ Aurora 75',
      description: 'Layout 75%, hot-swap, LED RGB và kết nối ba chế độ.',
      price: 1690000,
      image_url: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=1200&q=80',
      stock: 12,
      category: 'Phụ kiện'
    },
    {
      name: 'Chuột không dây Glide X',
      description: 'Cảm biến chính xác cao, trọng lượng nhẹ, pin dùng đến 70 giờ.',
      price: 890000,
      image_url: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?auto=format&fit=crop&w=1200&q=80',
      stock: 25,
      category: 'Phụ kiện'
    },
    {
      name: 'Đồng hồ thông minh Pulse S',
      description: 'Theo dõi vận động, giấc ngủ, nhịp tim và nhận thông báo.',
      price: 2190000,
      image_url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1200&q=80',
      stock: 9,
      category: 'Thiết bị đeo'
    },
    {
      name: 'Loa mini Orbit',
      description: 'Thiết kế nhỏ gọn, chống nước IPX7, âm thanh 360 độ.',
      price: 790000,
      image_url: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=1200&q=80',
      stock: 20,
      category: 'Âm thanh'
    },
    {
      name: 'Webcam Studio 2K',
      description: 'Độ phân giải 2K, tự động lấy nét, micro kép khử ồn.',
      price: 1490000,
      image_url: 'https://images.unsplash.com/photo-1587826080692-f439cd0b70da?auto=format&fit=crop&w=1200&q=80',
      stock: 15,
      category: 'Thiết bị văn phòng'
    }
  ];

  for (const item of items) {
    const timestamp = now();
    state.products.push({
      id: state.meta.nextProductId++,
      ...item,
      is_active: 1,
      created_at: timestamp,
      updated_at: timestamp
    });
  }
}

function findUserByUsername(username) {
  const user = state.users.find((item) => item.username === username);
  return user ? clone(user) : null;
}

function listProducts({ search = '', category = '', activeOnly = true } = {}) {
  const normalizedSearch = search.toLocaleLowerCase('vi-VN');
  return state.products
    .filter((product) => !activeOnly || product.is_active === 1)
    .filter((product) => !category || product.category === category)
    .filter((product) => {
      if (!normalizedSearch) return true;
      return `${product.name} ${product.description}`
        .toLocaleLowerCase('vi-VN')
        .includes(normalizedSearch);
    })
    .sort((a, b) => b.id - a.id)
    .map(clone);
}

function getProduct(id, { activeOnly = false } = {}) {
  const product = state.products.find((item) => item.id === Number(id));
  if (!product || (activeOnly && product.is_active !== 1)) return null;
  return clone(product);
}

function getProductsByIds(ids, { activeOnly = false } = {}) {
  const idSet = new Set(ids.map(Number));
  return state.products
    .filter((item) => idSet.has(item.id))
    .filter((item) => !activeOnly || item.is_active === 1)
    .map(clone);
}

function getCategories() {
  return [...new Set(
    state.products.filter((item) => item.is_active === 1).map((item) => item.category)
  )].sort((a, b) => a.localeCompare(b, 'vi'));
}

function createProduct(product) {
  const timestamp = now();
  const record = {
    id: state.meta.nextProductId++,
    ...product,
    created_at: timestamp,
    updated_at: timestamp
  };
  state.products.push(record);
  saveState();
  return clone(record);
}

function updateProduct(id, changes) {
  const index = state.products.findIndex((item) => item.id === Number(id));
  if (index < 0) return null;
  state.products[index] = {
    ...state.products[index],
    ...changes,
    id: state.products[index].id,
    updated_at: now()
  };
  saveState();
  return clone(state.products[index]);
}

function hideProduct(id) {
  return updateProduct(id, { is_active: 0 });
}

function createOrder(form, cart) {
  const draft = clone(state);
  const cartEntries = Object.entries(cart || {})
    .map(([id, quantity]) => ({ id: Number(id), quantity: Number(quantity) }))
    .filter((entry) => Number.isInteger(entry.id) && Number.isInteger(entry.quantity) && entry.quantity > 0);

  if (!cartEntries.length) throw new Error('Giỏ hàng đang trống.');

  const items = cartEntries.map((entry) => {
    const product = draft.products.find((item) => item.id === entry.id && item.is_active === 1);
    if (!product) throw new Error('Một sản phẩm trong giỏ không còn được bán.');
    if (product.stock < entry.quantity) {
      throw new Error(`Sản phẩm “${product.name}” không còn đủ số lượng.`);
    }
    return { product, quantity: entry.quantity };
  });

  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const shippingFee = subtotal >= 1500000 ? 0 : 30000;
  const timestamp = now();
  const order = {
    id: draft.meta.nextOrderId++,
    customer_name: form.customer_name,
    email: form.email,
    phone: form.phone,
    address: form.address,
    note: form.note,
    shipping_fee: shippingFee,
    total: subtotal + shippingFee,
    status: 'pending',
    created_at: timestamp,
    updated_at: timestamp
  };
  draft.orders.push(order);

  for (const { product, quantity } of items) {
    draft.orderItems.push({
      id: draft.meta.nextOrderItemId++,
      order_id: order.id,
      product_id: product.id,
      product_name: product.name,
      price: product.price,
      quantity
    });
    product.stock -= quantity;
    product.updated_at = timestamp;
  }

  saveState(draft);
  return clone(order);
}

function listOrders(status = '') {
  return state.orders
    .filter((order) => !status || order.status === status)
    .sort((a, b) => b.id - a.id)
    .map(clone);
}

function getOrder(id) {
  const order = state.orders.find((item) => item.id === Number(id));
  return order ? clone(order) : null;
}

function getOrderItems(orderId) {
  return state.orderItems
    .filter((item) => item.order_id === Number(orderId))
    .map(clone);
}

function updateOrderStatus(id, status) {
  const index = state.orders.findIndex((item) => item.id === Number(id));
  if (index < 0) return null;
  state.orders[index].status = status;
  state.orders[index].updated_at = now();
  saveState();
  return clone(state.orders[index]);
}

function getDashboardStats() {
  return {
    products: state.products.filter((item) => item.is_active === 1).length,
    orders: state.orders.length,
    pending: state.orders.filter((item) => item.status === 'pending').length,
    revenue: state.orders
      .filter((item) => item.status === 'completed')
      .reduce((sum, item) => sum + item.total, 0)
  };
}

function getRecentOrders(limit = 8) {
  return listOrders().slice(0, limit);
}

module.exports = {
  initializeDatabase,
  verifyPassword,
  findUserByUsername,
  listProducts,
  getProduct,
  getProductsByIds,
  getCategories,
  createProduct,
  updateProduct,
  hideProduct,
  createOrder,
  listOrders,
  getOrder,
  getOrderItems,
  updateOrderStatus,
  getDashboardStats,
  getRecentOrders
};
