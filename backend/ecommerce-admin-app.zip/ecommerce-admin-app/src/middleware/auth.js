function requireAdmin(req, res, next) {
  if (req.session?.user?.role === 'admin') return next();
  req.session.returnTo = req.originalUrl;
  return res.redirect('/admin/login');
}

function redirectIfAdmin(req, res, next) {
  if (req.session?.user?.role === 'admin') return res.redirect('/admin');
  return next();
}

module.exports = { requireAdmin, redirectIfAdmin };
