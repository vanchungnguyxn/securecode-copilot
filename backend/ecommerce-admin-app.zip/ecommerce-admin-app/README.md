# Nova Store — website bán hàng có Admin

Project mẫu full-stack bằng Node.js, Express, EJS và database JSON lưu trực tiếp trên máy.

## Tính năng

- Trang chủ hiển thị, tìm kiếm và lọc sản phẩm.
- Trang chi tiết sản phẩm.
- Giỏ hàng lưu bằng session.
- Form đặt hàng và tự động trừ tồn kho.
- Đăng nhập admin ngay trên web tại `/admin/login`.
- Dashboard thống kê sản phẩm, đơn hàng và doanh thu.
- Admin thêm, sửa, ẩn sản phẩm.
- Admin xem chi tiết và cập nhật trạng thái đơn hàng.
- Mật khẩu admin được băm bằng bcrypt.
- Có giới hạn số lần thử đăng nhập.
- Giao diện responsive cho máy tính và điện thoại.

## Chạy project

Yêu cầu Node.js 18 trở lên.

```bash
npm install
cp .env.example .env
npm run dev
```

Mở:

- Cửa hàng: `http://localhost:3000`
- Admin: `http://localhost:3000/admin/login`

Tài khoản mặc định nếu chưa sửa `.env`:

```text
Tên đăng nhập: admin
Mật khẩu: Admin@123
```

Hãy đổi `SESSION_SECRET` và `ADMIN_PASSWORD` trước khi triển khai thật. Nếu đã chạy project rồi mới đổi tài khoản admin, hãy xóa `data/shop.json` để hệ thống tạo lại database với thông tin mới.

## Cấu trúc chính

```text
server.js                  Route cửa hàng và admin
src/db.js                  Database JSON, tài khoản và dữ liệu mẫu
src/middleware/auth.js     Middleware bảo vệ trang admin
views/                     Giao diện EJS
public/css/styles.css      Giao diện responsive
public/js/app.js           Tương tác phía trình duyệt
data/shop.json             Database, tự tạo khi chạy lần đầu
```

## Ghi chú triển khai production

- Dùng HTTPS và đặt `NODE_ENV=production`.
- Thay database JSON bằng PostgreSQL/MySQL và session MemoryStore bằng Redis khi có nhiều người dùng.
- Thêm CSRF protection cho các form thay đổi dữ liệu.
- Dùng dịch vụ lưu ảnh thay vì nhập URL thủ công.
- Thiết lập reverse proxy bằng Nginx hoặc dùng nền tảng như Railway/Render/VPS.
