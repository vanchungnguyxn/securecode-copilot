require('dotenv').config();

const path = require('path');
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const store = require('./src/db');
const { requireAdmin, redirectIfAdmin } = require('./src/middleware/auth');

store.initializeDatabase();

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ORDER_STATUSES = ['pending', 'confirmed', 'shipping', 'completed', 'cancelled'];

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.urlencoded({ extended: false, limit: '100kb' }));
app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(
  session({
    name: 'shop.sid',
    secret: process.env.SESSION_SECRET || 'dev-secret-change-me',
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production',
      maxAge: 1000 * 60 * 60 * 8
    }
  })
);

app.locals.money = (value) =>
  new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
    maximumFractionDigits: 0
  }).format(Number(value || 0));

app.locals.statusLabel = (status) => ({
  pending: 'Chờ xác nhận',
  confirmed: 'Đã xác nhận',
  shipping: 'Đang giao',
  completed: 'Hoàn thành',
  cancelled: 'Đã hủy'
}[status] || status);

app.use((req, res, next) => {
  const cart = req.session.cart || {};
  res.locals.cartCount = Object.values(cart).reduce((sum, qty) => sum + Number(qty), 0);
  res.locals.currentUser = req.session.user || null;
  res.locals.currentPath = req.path;
  res.locals.flash = req.session.flash || null;
  delete req.session.flash;
  next();
});

function setFlash(req, type, message) {
  req.session.flash = { type, message };
}

function cleanText(value, maxLength = 500) {
  return String(value || '').trim().slice(0, maxLength);
}

function positiveInt(value, fallback = 1) {
  const parsed = Number.parseInt(value, 10);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback;
}

function nonNegativeInt(value, fallback = 0) {
  const parsed = Number.parseInt(value, 10);
  return Number.isInteger(parsed) && parsed >= 0 ? parsed : fallback;
}

function getCartItems(cart) {
  const ids = Object.keys(cart || {}).map(Number).filter(Number.isInteger);
  if (!ids.length) return [];

  return store.getProductsByIds(ids, { activeOnly: true })
    .map((product) => {
      const quantity = Math.min(positiveInt(cart[product.id], 1), product.stock);
      return {
        ...product,
        quantity,
        subtotal: product.price * quantity
      };
    })
    .filter((item) => item.quantity > 0);
}

function cartTotals(items) {
  const subtotal = items.reduce((sum, item) => sum + item.subtotal, 0);
  const shippingFee = subtotal >= 1500000 ? 0 : 30000;
  return { subtotal, shippingFee, total: subtotal + shippingFee };
}

// Cửa hàng
app.get('/', (req, res) => {
  const search = cleanText(req.query.search, 80);
  const category = cleanText(req.query.category, 80);
  const products = store.listProducts({ search, category, activeOnly: true });
  const categories = store.getCategories();

  res.render('shop', { title: 'Nova Store', products, categories, search, category });
});

app.get('/product/:id', (req, res) => {
  const product = store.getProduct(req.params.id, { activeOnly: true });
  if (!product) return res.status(404).render('404', { title: 'Không tìm thấy sản phẩm' });
  return res.render('product-detail', { title: product.name, product });
});

app.post('/cart/add', (req, res) => {
  const productId = positiveInt(req.body.productId, 0);
  const quantity = positiveInt(req.body.quantity, 1);
  const product = store.getProduct(productId, { activeOnly: true });

  if (!product || product.stock <= 0) {
    setFlash(req, 'error', 'Sản phẩm không tồn tại hoặc đã hết hàng.');
    return res.redirect(req.get('referer') || '/');
  }

  req.session.cart = req.session.cart || {};
  const current = positiveInt(req.session.cart[productId], 0);
  req.session.cart[productId] = Math.min(current + quantity, product.stock);
  setFlash(req, 'success', `Đã thêm “${product.name}” vào giỏ hàng.`);
  return res.redirect(req.get('referer') || '/cart');
});

app.get('/cart', (req, res) => {
  const items = getCartItems(req.session.cart || {});
  const totals = cartTotals(items);
  res.render('cart', { title: 'Giỏ hàng', items, ...totals });
});

app.post('/cart/update', (req, res) => {
  const productId = positiveInt(req.body.productId, 0);
  const quantity = nonNegativeInt(req.body.quantity, 1);
  const product = store.getProduct(productId);

  req.session.cart = req.session.cart || {};
  if (!product || product.is_active !== 1 || quantity === 0 || product.stock === 0) {
    delete req.session.cart[productId];
  } else {
    req.session.cart[productId] = Math.min(quantity, product.stock);
  }

  return res.redirect('/cart');
});

app.post('/cart/remove', (req, res) => {
  const productId = positiveInt(req.body.productId, 0);
  req.session.cart = req.session.cart || {};
  delete req.session.cart[productId];
  return res.redirect('/cart');
});

app.get('/checkout', (req, res) => {
  const items = getCartItems(req.session.cart || {});
  if (!items.length) return res.redirect('/cart');
  const totals = cartTotals(items);
  return res.render('checkout', {
    title: 'Thanh toán', items, ...totals, errors: [], form: {}
  });
});

app.post('/checkout', (req, res) => {
  const form = {
    customer_name: cleanText(req.body.customer_name, 100),
    email: cleanText(req.body.email, 120),
    phone: cleanText(req.body.phone, 30),
    address: cleanText(req.body.address, 250),
    note: cleanText(req.body.note, 500)
  };

  const errors = [];
  if (form.customer_name.length < 2) errors.push('Vui lòng nhập họ tên hợp lệ.');
  if (!/^\S+@\S+\.\S+$/.test(form.email)) errors.push('Email chưa đúng định dạng.');
  if (!/^[0-9+\s.-]{8,20}$/.test(form.phone)) errors.push('Số điện thoại chưa hợp lệ.');
  if (form.address.length < 8) errors.push('Vui lòng nhập địa chỉ nhận hàng đầy đủ.');

  const items = getCartItems(req.session.cart || {});
  const totals = cartTotals(items);

  if (!items.length) return res.redirect('/cart');
  if (errors.length) {
    return res.status(422).render('checkout', {
      title: 'Thanh toán', items, ...totals, errors, form
    });
  }

  try {
    const order = store.createOrder(form, req.session.cart);
    req.session.cart = {};
    req.session.lastOrderId = order.id;
    return res.redirect(`/order/success/${order.id}`);
  } catch (error) {
    return res.status(409).render('checkout', {
      title: 'Thanh toán', items, ...totals, errors: [error.message], form
    });
  }
});

app.get('/order/success/:id', (req, res) => {
  const orderId = positiveInt(req.params.id, 0);
  if (req.session.lastOrderId !== orderId) return res.redirect('/');

  const order = store.getOrder(orderId);
  if (!order) return res.redirect('/');
  const items = store.getOrderItems(orderId);
  return res.render('order-success', { title: 'Đặt hàng thành công', order, items });
});

// Đăng nhập admin
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: 'Bạn đã thử đăng nhập quá nhiều lần. Vui lòng thử lại sau.'
});

app.get('/admin/login', redirectIfAdmin, (req, res) => {
  res.render('admin/login', { title: 'Đăng nhập quản trị', error: null });
});

app.post('/admin/login', redirectIfAdmin, loginLimiter, (req, res) => {
  const username = cleanText(req.body.username, 80);
  const password = String(req.body.password || '');
  const user = store.findUserByUsername(username);

  if (!user || !store.verifyPassword(password, user.password_hash)) {
    return res.status(401).render('admin/login', {
      title: 'Đăng nhập quản trị',
      error: 'Tên đăng nhập hoặc mật khẩu không đúng.'
    });
  }

  const destination = req.session.returnTo || '/admin';
  req.session.regenerate((error) => {
    if (error) return res.status(500).send('Không thể tạo phiên đăng nhập.');
    req.session.user = { id: user.id, username: user.username, role: user.role };
    return res.redirect(destination);
  });
});

app.post('/admin/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/admin/login'));
});

// Trang quản trị
app.get('/admin', requireAdmin, (req, res) => {
  const stats = store.getDashboardStats();
  const recentOrders = store.getRecentOrders(8);
  res.render('admin/dashboard', { title: 'Tổng quan quản trị', stats, recentOrders });
});

app.get('/admin/products', requireAdmin, (req, res) => {
  const products = store.listProducts({ activeOnly: false });
  res.render('admin/products', { title: 'Quản lý sản phẩm', products });
});

app.get('/admin/products/new', requireAdmin, (req, res) => {
  res.render('admin/product-form', {
    title: 'Thêm sản phẩm', product: null, errors: []
  });
});

function validateProduct(body) {
  const product = {
    name: cleanText(body.name, 150),
    description: cleanText(body.description, 2000),
    price: nonNegativeInt(body.price, -1),
    image_url: cleanText(body.image_url, 1000),
    stock: nonNegativeInt(body.stock, -1),
    category: cleanText(body.category, 100) || 'Khác',
    is_active: body.is_active === '1' ? 1 : 0
  };
  const errors = [];
  if (product.name.length < 2) errors.push('Tên sản phẩm phải có ít nhất 2 ký tự.');
  if (product.price < 0) errors.push('Giá sản phẩm không hợp lệ.');
  if (product.stock < 0) errors.push('Tồn kho không hợp lệ.');
  if (product.image_url && !/^https?:\/\//i.test(product.image_url)) {
    errors.push('Ảnh sản phẩm phải là một URL bắt đầu bằng http:// hoặc https://.');
  }
  return { product, errors };
}

app.post('/admin/products', requireAdmin, (req, res) => {
  const { product, errors } = validateProduct(req.body);
  if (errors.length) {
    return res.status(422).render('admin/product-form', {
      title: 'Thêm sản phẩm', product, errors
    });
  }

  store.createProduct(product);
  setFlash(req, 'success', 'Đã thêm sản phẩm mới.');
  return res.redirect('/admin/products');
});

app.get('/admin/products/:id/edit', requireAdmin, (req, res) => {
  const product = store.getProduct(req.params.id);
  if (!product) return res.status(404).render('404', { title: 'Không tìm thấy sản phẩm' });
  return res.render('admin/product-form', { title: 'Sửa sản phẩm', product, errors: [] });
});

app.post('/admin/products/:id', requireAdmin, (req, res) => {
  const existing = store.getProduct(req.params.id);
  if (!existing) return res.status(404).render('404', { title: 'Không tìm thấy sản phẩm' });

  const { product, errors } = validateProduct(req.body);
  product.id = existing.id;
  if (errors.length) {
    return res.status(422).render('admin/product-form', {
      title: 'Sửa sản phẩm', product, errors
    });
  }

  store.updateProduct(existing.id, product);
  setFlash(req, 'success', 'Đã cập nhật sản phẩm.');
  return res.redirect('/admin/products');
});

app.post('/admin/products/:id/delete', requireAdmin, (req, res) => {
  store.hideProduct(req.params.id);
  setFlash(req, 'success', 'Đã ẩn sản phẩm khỏi cửa hàng.');
  return res.redirect('/admin/products');
});

app.get('/admin/orders', requireAdmin, (req, res) => {
  const status = cleanText(req.query.status, 30);
  const selectedStatus = ORDER_STATUSES.includes(status) ? status : '';
  const orders = store.listOrders(selectedStatus);
  res.render('admin/orders', {
    title: 'Quản lý đơn hàng', orders, status: selectedStatus, statuses: ORDER_STATUSES
  });
});

app.get('/admin/orders/:id', requireAdmin, (req, res) => {
  const order = store.getOrder(req.params.id);
  if (!order) return res.status(404).render('404', { title: 'Không tìm thấy đơn hàng' });
  const items = store.getOrderItems(order.id);
  return res.render('admin/order-detail', {
    title: `Đơn hàng #${order.id}`, order, items, statuses: ORDER_STATUSES
  });
});

app.post('/admin/orders/:id/status', requireAdmin, (req, res) => {
  const status = cleanText(req.body.status, 30);
  if (!ORDER_STATUSES.includes(status)) {
    setFlash(req, 'error', 'Trạng thái đơn hàng không hợp lệ.');
    return res.redirect(`/admin/orders/${req.params.id}`);
  }

  store.updateOrderStatus(req.params.id, status);
  setFlash(req, 'success', 'Đã cập nhật trạng thái đơn hàng.');
  return res.redirect(`/admin/orders/${req.params.id}`);
});

app.use((req, res) => {
  res.status(404).render('404', { title: 'Không tìm thấy trang' });
});

app.use((error, req, res, next) => {
  console.error(error);
  if (res.headersSent) return next(error);
  return res.status(500).render('500', { title: 'Lỗi hệ thống' });
});

app.listen(PORT, () => {
  console.log(`Website đang chạy tại http://localhost:${PORT}`);
  console.log(`Trang admin: http://localhost:${PORT}/admin/login`);
});
